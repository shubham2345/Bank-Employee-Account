<html>
<?php

echo "welcome manas.";

?>
</html>