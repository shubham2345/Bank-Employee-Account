<!DOCTYPE html>
<html>
<body>

<?php
   $y=strtotime("10:30:14 pm April 15 2016");
   echo "The date created is ".date("Y-m-d  h:i:s a",$y);
?>

</body>
</html>