<!DOCTYPE html>
<html>
<body>

<?php
 define("Greeting", "Welcome to w3schools.com!",true);
 echo greeting;
?>

</body>
</html>