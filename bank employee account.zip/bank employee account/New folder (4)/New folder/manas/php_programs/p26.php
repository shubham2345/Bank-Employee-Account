<!DOCTYPE html>
<html>
<body>

<?php
  $num['G']= "789";
  $num['B']= "687";
  $num['I']= "875";
  echo "G is ".$num['G']." And I is ".$num['I'];
 ?>

</body>
</html>