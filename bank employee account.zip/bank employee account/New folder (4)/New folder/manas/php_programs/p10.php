<!DOCTYPE html>
<html>
<body>

<?php
 $t=date("H");
 
 if($t<"12")
   echo "Good Morning";
 elseif($t<"20")
   echo "Have a good day";
 else
   echo "Good night";
?>

</body>
</html>