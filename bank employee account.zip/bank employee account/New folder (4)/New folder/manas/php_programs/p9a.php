<!DOCTYPE html>
<html>
<body>

<?php
 $a=10;
 $b=20;
 $c=$a+$b;
 echo $c;
?>

</body>
</html>