<!DOCTYPE html>
<html>
<body>

<?php
  $cars= array("Toyota", "Bmw","Audi");
  sort($cars);
  
  for($x=0; $x < count($cars);$x++)
   { echo $cars[$x] ;
     echo "<br>";}
?>

</body>
</html>