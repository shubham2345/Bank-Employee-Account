<!DOCTYPE html>
<html>
<body>

<?php
   $y=mktime(11,14,54,8,12,2014);
   echo "The date created is ".date("Y-m-d  h:i:s a",$y);
?>

</body>
</html>