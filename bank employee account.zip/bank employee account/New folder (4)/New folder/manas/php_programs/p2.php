<!DOCTYPE html>
<html>
<body>

<?php
echo strlen("Hello world!"); // outputs 12
?>

</body>
</html>