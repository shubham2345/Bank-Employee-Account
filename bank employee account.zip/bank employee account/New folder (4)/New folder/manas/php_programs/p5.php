<!DOCTYPE html>
<html>
<body>

<?php
 echo strpos("Hello world!","o");
?>
</body>
</html>