<!DOCTYPE html>
<html>
<body>

<?php
 $x= 6;
  do
 {
    echo "The Number is: $x"."<br>"; // or echo "The Number is: $x<br>";
    $x++;
 }while($x<=5)
?>

</body>
</html>