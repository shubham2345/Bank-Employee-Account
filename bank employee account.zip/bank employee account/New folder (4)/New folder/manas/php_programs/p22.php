<!DOCTYPE html>
<html>
<body>

<?php
  $cars= array("Toyota", "Bmw","Audi");
  echo count($cars);
?>

</body>
</html>