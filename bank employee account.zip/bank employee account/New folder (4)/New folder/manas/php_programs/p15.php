<!DOCTYPE html>
<html>
<body>

<?php
  $colors= array("red", "yellow", "green", "blue");
  
  foreach($colors as $value)
    echo "$value <br>";
  
?>

</body>
</html>