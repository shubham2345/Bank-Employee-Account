<!DOCTYPE html>
<html>
<body>

<?php
   $y=strtotime("tomorrow");
   echo "The date created is ".date("Y-m-d  h:i:s a",$y);
   echo "<br>";

   $y=strtotime("Wednesday");
   echo "The date created is ".date("Y-m-d  h:i:s a",$y);
   echo "<br>";

   $y=strtotime("next week Wednesday");
   echo "The date created is ".date("Y-m-d  h:i:s a",$y);
   echo "<br>";

   $y=strtotime("+6 months");
   echo "The date created is ".date("Y-m-d  h:i:s a",$y);
   echo "<br>";
?>

</body>
</html>