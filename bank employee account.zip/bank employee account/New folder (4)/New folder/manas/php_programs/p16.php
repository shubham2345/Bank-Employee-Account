<!DOCTYPE html>
<html>
<body>

<?php
  function familyname($fname)
  { echo "$fname Das <br>";}
  
  familyname("Manas");
  familyname("Malay");
  familyname("Ashish");
?>

</body>
</html>