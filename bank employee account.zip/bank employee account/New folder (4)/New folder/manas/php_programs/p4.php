<!DOCTYPE html>
<html>
<body>

<?php
 echo strrev("Helloe world!");
?>
</body>
</html>