<!DOCTYPE html>
<html>
<body>

<?php
 $x= 1;
  while($x<=5)
 {
    echo "The Number is: $x"."<br>"; // or echo "The Number is: $x<br>";
    $x++;
 }
?>

</body>
</html>