<!DOCTYPE html>
<html>
<body>

<?php
 $favcolor="black";

 switch($favcolor)
 {
  case "red":   
     echo " Your favourite color is red";
     break;
  case "blue":   
     echo " Your favourite color is blue";
     break;
  case "green":   
     echo " Your favourite color is green";
     break;
  case "yellow":   
     echo " Your favourite color is yellow";
     break;
  default:   
     echo " Your favourite color is something else";
     
  
 }
?>

</body>
</html>