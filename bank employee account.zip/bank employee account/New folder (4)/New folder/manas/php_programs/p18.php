<!DOCTYPE html>
<html>
<body>

<?php
  function setheight($minheight = 50)
  { echo "The Height is: $minheight <br>";}
  
  setheight(350);
  setheight();
  setheight(100);
?>

</body>
</html>