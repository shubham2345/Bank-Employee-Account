<!DOCTYPE html>
<html>
<body>

<?php
  echo "Today is " . date("Y/m/d") . "<br>";
  echo "Today is " . date("Y.m.d") . "<br>";
  echo "Today is " . date("Y-m-d") . "<br>";
  echo "Today is " . date("Y  m  d") . "<br>";
  echo "Today is " . date("d/m/Y") . "<br>";
  echo "Today is " . date("l") . "<br>";
  echo "Today is (with small y) " . date("y/m/d") . "<br>";
 ?>

</body>
</html>