<html>

<head>
<title>Divisible by 5</title>
</head>

<body>
<?php
 $y=99;
 for($x=1;$x<=$y;$x++)
  { 
    if($y%$x==0)
      {
        echo "Factors:".$x;
        echo "<br>";
      }
     
  }
?>
</body>

</html>

