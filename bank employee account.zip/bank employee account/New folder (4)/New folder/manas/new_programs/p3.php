<html>

<head>
<title>Check prime</title>
</head>

<body>
<?php

 $y=13;
 $flagg=0;
 for($x=2;$x<$y;$x++)
  { 
    if($y%$x==0)
      {
        $flagg++;
      }
     
  }
 if($flagg==0)
   echo "$y "."is a Prime Number";
 else
   echo "$y "."is not a Prime Number";
?>
</body>

</html>

