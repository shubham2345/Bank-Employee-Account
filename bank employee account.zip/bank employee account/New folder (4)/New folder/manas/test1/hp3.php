<html>

<head>
<title>Password Check</title>
</head>

<body>

 Welcome <?php echo $_POST["name"];?><br>
 <?php
    if($_POST["pwd"]==12345)
       echo "SUCCESS";
    else
       echo "FAILURE";
  ?>


<form action="hp3.php" method="post">
  Name:<input type="text" name="name"><br>
  Password:<input type="text" name="pwd"><br>
  <br>
  <input type="submit" name="submit"><br>
</form>


</body>

</html>