<html>
<body>

<?php

$x=$_POST["no1"];
$y=$_POST["no2"];
$p=$_POST["operator"];
$z=$_POST["result"];

if ($z=="result")
{
  switch ($p)
  {
    case "+":
      $q=$x+$y;
      break;
    case "-":
      $q=$x-$y;
      break;
    case "*":
      $q=$x*$y;
      break;
    case "/":
      $q=$x/$y;
      break;
    default:
      $q=0;
  }
}


?>


<form action="cal_switch.php" method="post">
1st number<input type="text" name="no1" value="<?php echo $x;?>">
<select name="operator">
<option name="" value="">
<option name="add" value="+">+
<option name="minus" value="-">-
<option name="mult" value="*">*
<option name="div" value="/">/
</select>


2nd number<input type="text" name="no2" value="<?php echo $y;?>"><br>
<input type="submit" name="result" value="result">
result is<input type="text" name="operation" value="<?php echo $q;?>">
</form>

</body>
</html>