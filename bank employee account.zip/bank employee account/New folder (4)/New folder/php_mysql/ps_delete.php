<html>

<head>
<title>Php with Mysql</title>
</head>

<body>
<?php
  
  $servername="localhost";
  $username="root";
  $password="";
  $dbname="db1";

  $conn= new mysqli($servername,$username,$password,$dbname);

$x=$_POST["userid"];
$y=$_POST["pwd"];
$z=$_POST["inp"];

if($z=="Delete")
{
  $a="delete from password where userid='".$x."'";
  $result = $conn->query($a);
  if($result->num_rows > 0)
    echo "Deleted successfully";
  else
    echo "Delete Unsuccessfull.0 reults deleted.";
}

?>

<form action="ps_delete.php" method="post">
  Userid:<input type="text" name="userid"><br>
  Password:<input type="password" name="pwd">
  <br>
  <br>
  <input type="submit" name="inp" value="Delete">
</form>
</body>

</html>