<html>

<head>
<title>Php with Mysql</title>
</head>

<body>
<?php
  
  $servername="localhost";
  $username="root";
  $password="";
  $dbname="db1";

  $conn= new mysqli($servername,$username,$password,$dbname);

$x=$_POST["userid"];
$y=$_POST["pwd"];
$z=$_POST["add"];

if($z=="insert")
{
  $a="insert into password values('".$x."','".$y."')";
  $result = $conn -> query($a);
  echo "inserted successfully";
}

?>

<form action="ps1.php" method="post">
  Userid:<input type="text" name="userid"><br>
  Password:<input type="password" name="pwd">
  <br>
  <br>
  <input type="submit" name="add" value="insert">
</form>
</body>

</html>