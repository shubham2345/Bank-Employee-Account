<html>

<head>
 <title>Transfer Page</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="transfer.css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  function transfer()
  {
    var abc=form1.don.value;
    var xyz=form1.rec.value;
    window.location.href="transfer.php?tran="+abc+"&tran1="+xyz;
  }
  </script>
</head>

<body>
<?php
 session_start();
  include "config.php";
  if(!isset($_SESSION["don"]))
  {
   $_SESSION["don"]=$_GET["tran"];
   $_SESSION["rec"]=$_GET["tran1"];
  }
  $uid=$_SESSION["uid"];
  $r=$_GET["tran1"];
  $d=$_GET["tran"];
  $dat=$_POST["dt"];
  $descrip=$_POST["des"];
  $amm=$_POST["amt"];
  $sub=$_POST["submit"];
  if($sub=="Transfer")
     {
        $sql1="insert into transaction values('".$uid."','".$dat."','Withdrawl','".$descrip."','".$amm."','".$_SESSION["don"]."')";
        $result=$conn->query($sql1);
        $sql1="insert into transaction values('".$uid."','".$dat."','Deposit','".$descrip."','".$amm."','".$_SESSION["rec"]."')";
        $result=$conn->query($sql1);
     }
  $sql2="select * from account_master where acc_no='".$d."'";
  $rr1=$conn->query($sql2);
  $row=$rr1->fetch_assoc();
  $b=$row[open_bal];
  $cb=$b;
  $sql="select * from transaction where acc_no='".$d."'";
  $rr=$conn->query($sql);
  
   while($row=$rr->fetch_assoc())
   {
     if($row[tr_type]=="Withdrawl")
             $cb=$cb-$row[amount];
          else
            $cb=$cb+$row[amount];
   }
?>
 <div id="container">
  <div id="zero">
    <nav class="navbar navbar-default ">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home2.php">SBI Bank</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home2.php">Home</a></li>
      <li><a href="new_acc.php">New Account</a></li>
      <li><a href="transaction_withdraw.php">Withdraw</a></li>
      <li><a href="transaction_deposit.php">Deposit</a></li>
      <li class="active"><a href="transfer.php">Transfer</a></li>
      <li><a href="report.php">Report</a></li>
      
    </ul>
  </div>
</nav>
</div>
  <div id="first">
     <pre>
     <form name=form1 action="transfer.php" method="POST">
      Account Numbers<br>
      Donor:         <input type="text" name="don" value="<?php echo "$d"; ?>"/>        <button type="button" onclick="transfer()">Check Balance</button><br>
      Recipient:     <input type="text" name="rec" value="<?php echo "$r"; ?>"/><br>
      
      <br>
      Ammount:       <input type="number" name="amt" min=100 max =<?php echo ($cb-2000); ?> /><br>
      Date:          <input type="Date" name="dt"/><br>
      Description:   <input type="text" name="des" value="Transfer from <?php echo "$d"; ?> to <?php echo "$r"; ?>"/>  
      <br><br>
      <center><input type="submit" name="submit" value="Transfer"/></center>
     </form>
     </pre>
    </div> 
 </div>
</body>

</html>