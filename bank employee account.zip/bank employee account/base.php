<html>

<head>
 <title>SBI Bank</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="base.css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
  <div id="container">
   <div id="header">
      <center><B>SBI Bank</B></center>
   </div>
   <div id="middle">
   
    
    <a target="inline" href="login.php" value="home" class="btn btn-primary btn-block" role="button">Login</a>
    
        
    <center><iframe src="home.php" name="inline" height=450px width=990px style="border:none;"></iframe></center>
    <frame>
      <frame
    </frame>
      </div>
   <div id="footer">
    &copy Manas Murarka
    <center><a target="inline" href="home.php" value="foot" class="btn btn-danger btn-md" role="button">Log out</button></a> 
   </div>
 </div>
</body>

</html>