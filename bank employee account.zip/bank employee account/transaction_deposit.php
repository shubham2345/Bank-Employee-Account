<html>

<head>
 <title>Transaction Deposit Page</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="transaction.css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  function tran()
  {
    var abc=form1.accno.value;
    window.location.href="transaction_deposit.php?tran="+abc;
  }
  </script>
</head>

<body>
<?php
  session_start();
  include "config.php";

  $uid=$_SESSION["uid"];
  $a=$_GET["tran"];
  $z=$_GET["tran2"];
  $sql="select * from account_master where acc_no='".$a."'";
  $rr=$conn->query($sql);
  $row=$rr->fetch_assoc();
  $b=$row[open_bal];
  $c=$row[name];
  $d=$row[phone];
  $e=$row[acc_type];
  $f=$row[address];
  
  
?>

 <div id="container">
  <div id="zero">
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home2.php">SBI Bank</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home2.php">Home</a></li>
      <li><a href="new_acc.php">New Account</a></li>
      <li><a href="transaction_withdraw.php">Withdraw</a></li>
      <li class="active"><a href="transaction_deposit.php">Deposit</a></li>
      <li><a href="transfer.php">Transfer</a></li>
      <li><a href="report.php">Report</a></li>
    </div>
   </div>
    <div id="first">
     <pre>
     <form name=form1 action="transaction_deposit.php" method="POST">
      Enter Account number: <input type="text" name="accno" value="<?php echo "$a" ; ?>" ><button type="button" onclick="tran()" >Balance</button>    
      <br>
      Ammount:<input type="text" name="amt" value="<?php echo "$b" ; ?>" readonly/><br>
      <br><br>
      Account details:<pre>
      Name:         <input type="text" name="amt" value="<?php echo "$c" ; ?>" readonly/>
      Phone:        <input type="text" name="amt" value="<?php echo "$d" ; ?>" readonly/>
      Account type: <input type="text" name="amt" value="<?php echo "$e" ; ?>" readonly/><br>
      Address:      <input type="text" name="amt" value="<?php echo "$f" ; ?>" readonly/><br>
      
      </pre>
      </form>
     </pre>
    </div>
 <?php
       $cb=$b;
       $sql="select * from transaction where acc_no='".$a."'";
       $rr=$conn->query($sql);
       while($row=$rr->fetch_assoc())
       {
          if($row[tr_type]=="Withdrawl")
             $cb=$cb-$row[amount];
          else
            $cb=$cb+$row[amount];
       }
     $acno=$_POST["accno"];
     $dat=$_POST["dt"];
     $tran_ty=$_POST["tr_type"];
     $amm=$_POST["amt2"];
     $descrip=$_POST["desc"];
     $sub=$_POST["submit"];
     if($sub=="Deposit")
     {
        $sql1="insert into transaction values('".$uid."','".$dat."','".$tran_ty."','".$descrip."','".$amm."','".$acno."')";
        $result=$conn->query($sql1);
     }
?> 
    <div id="second">
     <form name=form2 action="transaction_deposit.php" method="POST">
     <pre>
       Account number:   <input type="text" name="accno" value="<?php echo "$a" ; ?>" readonly/> <br> 
       Date:             <input type="Date" name="dt"/><br> 
       Transaction type: <input type="text" name="tr_type" value="Deposit" readonly/> <br>
       Ammount:          <input type="number" name="amt2" value="Enter amount>100"/><br>
       Description:<br>                         <textarea name="desc" rows=5 cols=50>Write Details Of Transaction</textarea><br>
       <center><input type="submit" name="submit" value="Deposit"/></center>
     </pre>
     </form>
    </div>  
 </div>
</body>

</html>