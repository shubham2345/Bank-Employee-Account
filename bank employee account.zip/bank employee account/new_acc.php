<html>

<head>
 <title>New Account Page</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" type="text/css" href="new_acc.css"/>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
 <?php
session_start();
  include "config.php";

    $fi="SBI00N2";
    $v=10000;
    $sql="select * from account_master ";
    $rr=$conn->query($sql);
    $no=0;
    
     while($row=$rr->fetch_assoc())
       {
        if(substr($row[acc_no],0,strlen($fi))==$fi)
        $no++; 
       }
    $no++;
    $v=$v+$no;
    $svt=$fi.substr($v,1,4);
  $uid=$_SESSION["uid"];
  $accno=$svt;
  $a=$_POST["nm"];
  $b=$_POST["ad"];
  $c=$_POST["ph"];
  $d=$_POST["at"];
  $e=$_POST["acc_no"];
  $f=$_POST["op_bal"];

  $x=$_POST["check"];
  if($x=="submit")
  {
   
    
   
   $sql="insert into account_master values('".$a."','".$b."','".$c."','".$accno."','".$uid."','".$f."','".$d."')";
  
   $rr=$conn->query($sql);

  $a="";
  $b="";
  $c="";
  $d="";
  $e="";
  $f="";
 
  }
 ?>
 <div id="zero">
     <nav class="navbar navbar-default ">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home2.php">SBI Bank</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home2.php">Home</a></li>
      <li class="active"><a href="new_acc.php">New Account</a></li>
      <li><a href="transaction_withdraw.php">Withdraw</a></li>
      <li><a href="transaction_deposit.php">Deposit</a></li>
      <li><a href="transfer.php">Transfer</a></li>
      <li><a href="report.php">Report</a></li>
      
    </ul>
  </div>
</nav>
   </div> 
 <div id="d1">
  <form action="new_acc.php" method="post">
   <center><h1>New Account</center>
   <pre>
    <br>
    Name:             <input type="text" name="nm" placeholder="Name"/><br>
    Address:          <input type="text" name="ad" placeholder="Permanent Address"/><br>
    Phone:            <input type="text" name="ph" placeholder="Mobile Number"/><br>
    Account type:     <select name="at">
                         <option> Select Account
                         <option value="Current"> Current Account
                         <option value="Savings"> Savings Account
                      </select> <br>
    Account Number:   <input type="text" name="acc_no" value=<?php echo $svt; ?> readonly/><br>
    Opening Balance:  <input type="text" name="op_bal" placeholder="Enter Ammount"/><br>
    
   </pre>
   <center><input type="submit" class="btn btn-lg btn-primary" value="submit" name="check"></center>
  </form>
 </div>
</body>

</html>