<html>

<head>
<title>Report Page</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="report.css"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<?php
 session_start();
  include "config.php";

  $uid=$_SESSION["uid"];
  $a=$_POST["accno"];
  $z=$_POST["submit"];

  if($z=="Check")
 { 
  $sql1="select * from account_master where acc_no='".$a."'";
  $rr1=$conn->query($sql1);
  $row1=$rr1->fetch_assoc();
  $nam=$row1[name];
  $bal=$row1[open_bal];
 }
?>
 <div id="container">
  <div id="zero">
     <nav class="navbar navbar-default ">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home2.php">SBI Bank</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home2.php">Home</a></li>
      <li><a href="new_acc.php">New Account</a></li>
      <li><a href="transaction_withdraw.php">Withdraw</a></li>
      <li><a href="transaction_deposit.php">Deposit</a></li>
      <li><a href="transfer.php">Transfer</a></li>
      <li class="active"><a href="report.php">Report</a></li>
      
    </ul>
  </div>
</nav>
  </div>
  <div id="first">
   <form name=form1 action="report.php" method="POST">
   Enter Account number:       <input type="text" name="accno" value="<?php echo "$a" ; ?>" ><input type="submit" name="submit" value="Check"/><br><br>
   The user id of employee is: <?php echo "$uid" ; ?>.<br><br>
   Name of customer:           <input type="text" name="nam_cus" value="<?php echo "$nam" ; ?>" readonly/>
   <br>
   <br>
   <table border="1" cellpadding="0"><center>
          <tr>
          <th width=100 text-align:center>DATE</th>
          <th width=400 text-align:center>DESCIPTION</th>
          <th width=150 text-align:center>WITHDRAWL</th>
          <th width=150 text-align:center>DEPOSIT</th>
          <th width=150 text-align:center>BALANCE</th>
          </tr>
   
<?php    
    if($z=="Check")
     { 
        $sql="select * from transaction where acc_no='".$a."'";
        $rr=$conn->query($sql);
        echo "<tr><td width=950  colspan=4 text-align:center> Opening Balance</td><td>$bal</td></tr>";
        while($row=$rr->fetch_assoc())
         {
            $c=$row[date];
            $d=$row[tr_type];
            $e=$row[descrip];
            $f=$row[amount];
            echo "<tr>";
            echo" <td width=100>$c</td>
                   <td width=400>$e</td>";
                  if($d=="Withdrawl")
                   {
		    $bal=$bal-$f;
                    echo"<td width=150>$f</td>
                         <td width=150></td>
                         <td width=150>$bal</td></tr>";
                    
                   }
                   else
                   {
                    $bal=$bal+$f;
                     echo"<td width=150></td>
                          <td width=150>$f</td>
                          <td width=150>$bal</td></tr>"; 
                   }
           } 
           echo "<tr><td width=950  colspan=4 text-align:center> Closing Balance</td><td>$bal</td></tr>";     
                   echo"</table>";
          
     }
?>
   </form>
  </div>
 </div>
</body>

</html>