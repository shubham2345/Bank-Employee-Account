<html>

<head>
 <title>Home-SBI</title>
 <link rel="stylesheet" type="text/css" href="home.css"/>
</head>

<body>
 <div id="d1">
 <center>
 <h1>You have successfully logged in</h1>
 <h4>Please proceed</h4>
 </center> 
 </div>
</body>

</html>